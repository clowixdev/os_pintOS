/*
  File for 'threads-pause-resume' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "devices/timer.h"

void test_threads_pause_resume(void) 
{
  msg("Not implemented.");
}
